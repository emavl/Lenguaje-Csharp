﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02_Ejercicio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Background("Numeros entre 0 y 100");
            int numero = 0;
            while( numero < 100)
            {
                if( (numero % 2) != 0 )
                {
                    Console.Write(numero + ", ");
                }
                numero ++;
            }

            Console.WriteLine("\n\n\n" +
                "\nPrecione una tecla para continuar . . ");
            Console.ReadLine();
        }

        public static void Background(string titulo)
        {
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.Red;
            Console.Clear();
            Console.Title = titulo;
        }
    }
}
