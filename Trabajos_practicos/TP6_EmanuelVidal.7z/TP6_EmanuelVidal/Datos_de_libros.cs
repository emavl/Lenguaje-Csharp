﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _15_winwosForm
{
    internal class Datos_de_libros
    {
        public Datos_de_libros()
        {

        }

        // Seccion de propiedades:

        public string Nombre { get; set; }
        public string Autor { get; set; }
        public string Genero { get; set; }
        public int Paginas { get; set; }

    }
}
