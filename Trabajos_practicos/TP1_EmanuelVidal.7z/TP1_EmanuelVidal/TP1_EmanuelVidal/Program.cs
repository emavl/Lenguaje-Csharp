﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* ─────────► Trabajo practico n° 1 - Emanuel vidal    */

namespace Clase1_HolaMundo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("hola mundo");

            // Se utiliza para dejar en espera la accion del usuario.
            Console.ReadKey();
        }
    }
}
