﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* ─────────► Trabajo practico n° 1 - Emanuel vidal    */


namespace Strings
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Precione una tecla para continuar . . .");
            Console.ReadKey();

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("chau mundo");
            Console.WriteLine();

            Console.WriteLine("Precione una tecla para salir . . .");
            Console.ReadKey();

        }
    }
}
